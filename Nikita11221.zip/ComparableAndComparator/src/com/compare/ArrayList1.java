package com.compare;

import java.util.ArrayList;

public class ArrayList1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<String>color=new ArrayList<String>();
color.add("black");
color.add("white");
color.add("red");
color.add("red");
System.out.println(color);
for(String i:color) {
	System.out.println(i);
}
	}

}
