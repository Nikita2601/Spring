package com.eb.model;

public class customer {

}
