package com.eb.model;

public class product {
 private int id;
 
}
