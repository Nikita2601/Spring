package com.designpattern;

public class abcNetwork extends CellularPlan {
	void getRate() {
		rate=1.50;
	}

}
