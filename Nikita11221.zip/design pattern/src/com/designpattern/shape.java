package com.designpattern;

public interface shape {
 void getshape(String shape);
}
