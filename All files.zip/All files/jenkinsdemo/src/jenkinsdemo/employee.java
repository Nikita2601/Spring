package jenkinsdemo;

public class employee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     String str="nikita";
     System.out.println("Hello"+" "+str);
     
	}

}
