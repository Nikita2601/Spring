package com.eb.pojo;

public class StockDetails {

}
