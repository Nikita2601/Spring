package com.eb.pojo;

public class Stock {

}
