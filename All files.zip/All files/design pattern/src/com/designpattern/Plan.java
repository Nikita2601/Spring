package com.designpattern;

public interface Plan {
 void getroi(double rate);
}
