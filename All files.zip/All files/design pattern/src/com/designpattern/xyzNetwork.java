package com.designpattern;

public class xyzNetwork extends CellularPlan{

	void getRate() {
		rate=1.75;
	}
}
