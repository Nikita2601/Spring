package com.march23.DemoMackito23;

public class Calculator {
	public int addition(int a, int b)
	{
		return a+b;
	}
	public int subtraction(int a, int b)
	{
		return a-b;
	}
}
